# Talland Stage app icon pack

## Android
Copy the contents of:
android/app/src/main/res/

into your project at:
android/app/src/main/res/

This pack includes:
- classic launcher icons (`ic_launcher.png`)
- adaptive icon foregrounds (`ic_launcher_foreground.png`)
- `mipmap-anydpi-v26/ic_launcher.xml`
- `values/colors.xml`

Then rebuild:
flutter clean
flutter run

## iOS
Replace:
ios/Runner/Assets.xcassets/AppIcon.appiconset

with the folder from this pack.

Then rebuild:
flutter clean
flutter run

## Play Store
Use `play_store_icon_512.png` for the Play Store listing.
